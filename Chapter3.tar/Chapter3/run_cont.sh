#!/bin/csh -f
#SBATCH -J mtrand
#SBATCH -A 3DEFNCT
#SBATCH -p dev
#SBATCH -n 8
#SBATCH -c 10
#SBATCH -t 0:10:00

#example to run 8 MPI * 5 thread hyrbid parallel on JFRS1

limit stacksize unlimited

setenv OMP_NUM_THREADS 5
setenv KMATH_RAND_JUMP_FILE_PATH /home/satake/KMATH_RANDOM-1.1/random/ptool/jump

#this code requires that input parameter file "input_cont.txt" exists in the same directory

srun ./kmrand_cont

#you may use "mpirun -np N kmrand_cont" in your environment
