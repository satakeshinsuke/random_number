### how to run the example
0, Compile the code by make command (edit Makefile according to your environment)
1, Make a work directly and copy "go_mt_mpi.sh" there
2, Edit "go_mt_mpi.sh" according to your environment
   (NJOB = number of mpi parallel, DIRCODE = where the source code is) 
3, Set NGO, NTURN, NRND
    ngo : index of sequential job [0,1,2,...]
    nturn : how many turns call grnd_mt in a job 
    nrnd : how many random numbers generated per a turn
4, qsub go_mt_mpi.sh
   If the code runs correctly, it will generate "out_XXX_YYY.txt", where
   XXX=ngo (sequential job id) and YYY=myrank(MPI rank), 
   and a present MT status file "grnd_buff_iXXX". 
5, For the initial job (ngo=0), MT random sequence on each MPI rank is 
   automatically initialized. 
   In a sequential job, for ngo>=1, the code reads "grnd_buff_i(ngo-1)" file 
   and continue generating the random number sequences from the last saved status.

Example output files in example/:
   SEQ/ : (NTURN=1000, NRND=1000) x 2 sequential job (ngo=0, 1)
   ONE/ :  NTURN=2000, NRND=1000 single job (ngo=0)
   6 MPI(x8 openmp) parallel job case on SX Aurora

   plot.gpl : plot and compare the two results.
   It plots the average and sigma of nrnd random numbers for nturn times.
   If the job continues correctly, SEQ/ and ONE/ outputs should coincide.
   Also check if ave. and sig. are ditributed around their ideal vaules,
   0.50 and sqrt(1/12), respectively.

