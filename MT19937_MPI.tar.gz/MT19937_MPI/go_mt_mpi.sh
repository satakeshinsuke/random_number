#!/bin/bash
#PBS --group 24264
#PBS -q small24VH
#PBS -T necmpi
#PBS -l elapstim_req=0:05:00
#PBS -v NJOB=6
#PBS --venode=${NJOB}
#PBS -v OMP_NUM_THREADS=8
#PBS --venum-lhost=8

#PBS -v VE_PROGINF=detail
#PBS -v NMPI_PROGINF=detail
#PBS -v OMP_STACKSIZE=4G

#PBS -v EXECF=gomt_sample.go


###PBS -v VE_TRACEBACK=VERBOSE

cd $PBS_O_WORKDIR

DIRCODE="/home/satake/FORTEC3D/F3D-MPS/OPEN-v4-2_MT_202308/MT19937_MPI"

cp -f ${DIRCODE}/${EXECF} ./
cp -f ${DIRCODE}/seed-mt19937-1024 ./

# ngo : index of sequential job [0,1,2,...]
# nturn : how many turns call grnd_mt in a job 
# nrnd : how many random numbers generated per a turn
NGO=0
NTURN=2000
NRND=1000

date
mpirun -np ${NJOB} ./${EXECF} ${NGO} ${NTURN} ${NRND}
date

